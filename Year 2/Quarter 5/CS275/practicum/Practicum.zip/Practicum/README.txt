Reed Ceniviva
Practicum CS275

run part1 practicum:
	open in a web browser, select which route to obtain information for, and hit submit. The data will be displayed bellow

run part2:
	install express and start the server by: node server.js
	in a web browser enter a URL such as 
		http://localhost:8080/part2?message=hello&count=4
	to get a resulting output.

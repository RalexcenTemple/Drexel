README for lab4
Reed Ceniviva

after arriving to the home of the lab, choose from the navigation area if you'd like to navigate to �home� �Calculator� or �Weather�.

Home:
	After clicking on home you should see that the page is empty and only the banner and the navigation links are still populating the site. At this point you can choose to click one of the three links or exit out.

Calculator:
	After clicking on calculator you will see the a Title, as well as a text input area and a drop down selection area, followed by a submit button. Enter a whole positive number into the text field, select if you want to calculate the summation or factorial of that number and hit submit, the result will be displayed bellow. After reaching this page you can then use the navigation to selected on of the three links or exit out.

Weather:
	After clicking the weather link you page will be populated with a Title and a text field input box, followed by a submit button. Enter a Wunderground weather key into the text field and then click submit. The bellow area will populate with information about the next 24 hours of weather in your area. After reaching this page you can use the navigation area to click one of the three links, or exit out of the page.

READEME

how to run the code:

1: In the text field, enter a positive, whole number such as 5.
2: From the drop down Menu select whether you would like to do a Summation Calculations or a Factorial Calculation
3: Click the submit button and the calculation result will be displayed bellow the button

note:
	If any incorrect information is provided as a result of the user's input leading up to them hitting the
	submit button, an error message will be displayed to indicate what might be the problem.
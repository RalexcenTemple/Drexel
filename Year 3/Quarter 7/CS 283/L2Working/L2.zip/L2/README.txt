This programming assignment tasked that two directories are given to the program "a" and "b".

from these two directories a & b:
	if a file in a does not exist in directory b, it should replicate it in b
	if a file in b does not exist in directory a, it should be deleted from b
	if a file exists in both directories, the most recently modified with replace the older

a log of the activities are to be printed out to the standard output

my program successfully moves and deletes files but I have run into some errors and run out of time

The make file will compile the code but the program itself will have to be run manually using:
./dirClean ./a ./b 


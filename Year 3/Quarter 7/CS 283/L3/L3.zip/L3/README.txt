Reed Ceniviva CS283 Lab3

using the make file:
	build: make all
	clean: make clean
	run client: ./client address port file


assignment was to make two programs for client and server

client makes the web request for the page name and displays the response to the user

server takes request and connects to client, finds file and produces a header and sends contents back.

